Change in Vision document:
	+ Product features: restructuring features, not based on actors.
﻿Change in Software Architecture Document:
        + No change.
	+ Complete part 5, 6.
﻿Change in Use Case Specification:
        + Reduce to 24 use cases.
        + New use case model, with 2 main actors: customer, admin (guest is a type of customer)
GitHub repo: https://github.com/PThinh440/Intro2SE-Grp7
Jira: https://tbngoc21.atlassian.net/jira/software/projects/I2G/boards/1/timeline
Google Drive: https://drive.google.com/drive/folders/1z5D0aYl6C6-bn9vDNEdsQJxKYw27Tu3h?usp=sharing
Figma: https://www.figma.com/team_invite/redeem/C3Q5qglkeX84T91Rh48T7U